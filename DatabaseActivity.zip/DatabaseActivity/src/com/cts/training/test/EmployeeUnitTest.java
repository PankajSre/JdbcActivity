package com.cts.training.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cts.training.bean.Employee;
import com.cts.training.dao.EmployeeDAO;
import com.cts.training.dao.impl.EmployeeDAOImpl;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

public class EmployeeUnitTest {

	private static EmployeeDAO employeeDAO;
	private static Employee employee;

	@BeforeClass
	public static void init() {
		employee = new Employee();
		employeeDAO = new EmployeeDAOImpl();
	}

	@Ignore
	@Test
	public void test_add_employee_success() {

		Employee emp = new Employee(133, "Bharat", "Mumbai", "Software Programmer", 22, 21700, 678687687L);
		assertEquals(true, employeeDAO.saveEmployee(emp));
	}
	
	
	@Ignore
	@Test(expected = NullPointerException.class)
	public void test_get_employee_by_id_success() {

		Employee emp = employeeDAO.getEmployeeById(100);
		assertEquals("Harshita", emp.getName());
	}
	@Ignore
	@Test
	public void test_get_all_employees_success() {

		List<Employee> list = employeeDAO.getAllEmployees();
		assertEquals("Mumbai", list.get(7).getAddress());
		
	}
	
	

}
