package com.cts.training.controller;

import java.util.List;

import com.cts.training.bean.Employee;
import com.cts.training.dao.EmployeeDAO;
import com.cts.training.dao.impl.EmployeeDAOImpl;;

public class EmployeeController {

	public static void main(String[] args) {
		EmployeeDAO empObj = new EmployeeDAOImpl();

		Employee employee = new Employee(124, "pankaj", "Test", "SD", 21, 324234, 5787855L);
		empObj.saveEmployee(employee);
//		List<Employee> list = empObj.getAllEmployees();
//		list.forEach(System.out::println);
		
//		Employee emp = empObj.getEmployeeById(111);
		//System.out.println(emp);
//		emp.setName("Naveen Kumar");
//		empObj.updateEmployee(emp);
//		empObj.deleteEmployee(emp);
		
		
		
	}

}
